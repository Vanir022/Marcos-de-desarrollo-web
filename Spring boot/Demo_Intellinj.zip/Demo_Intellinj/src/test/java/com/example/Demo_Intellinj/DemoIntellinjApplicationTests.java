package com.example.Demo_Intellinj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoIntellinjApplicationTests {

	@Test
	void contextLoads() {
	}

}
