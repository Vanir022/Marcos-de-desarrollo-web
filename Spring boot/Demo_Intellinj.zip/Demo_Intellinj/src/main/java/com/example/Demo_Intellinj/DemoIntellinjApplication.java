package com.example.Demo_Intellinj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoIntellinjApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoIntellinjApplication.class, args);
	}

}
