package com.example.Actividad6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;

@Import(TestcontainersConfiguration.class)
@SpringBootTest
class Actividad6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
