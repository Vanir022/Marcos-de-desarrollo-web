package com.vanir.Semana6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Semana6Application {

	public static void main(String[] args) {
		SpringApplication.run(Semana6Application.class, args);
	}

}
